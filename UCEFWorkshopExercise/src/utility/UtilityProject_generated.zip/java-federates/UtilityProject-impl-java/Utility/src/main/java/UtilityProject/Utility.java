package UtilityProject;

import c2w.hla.InteractionRoot;
import c2w.hla.ObjectRoot;
import c2w.hla.base.ObjectReflector;

import c2w.hla.base.AdvanceTimeRequest;

import hla.rti.SuppliedAttributes;
import hla.rti.jlc.RtiFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/**
 * The federate federate for the federation federation designed in WebGME.
 *
 * This federate MUST join the federation before the federation manager starts the experiment.
 * This means that, when the federate joins, the federation logical time must be 0 and both
 * the readyToPopulate and the readyToRun synchronization points must be defined.
 */
public class Utility extends UtilityBase {

    private final static Logger log = LogManager.getLogger(Utility.class);

   ///////////////////////////////////////////////////////////////////////
   // TODO Instatiate objects. that must be sent every logical time step 
   //
   //
   ///////////////////////////////////////////////////////////////////////

    public Utility(String[] args) throws Exception {
        super(args);
        ///////////////////////////////////////////////////////////////////////
        // TODO Must register object instances after super(args)
        //
        //
        ///////////////////////////////////////////////////////////////////////
}

    private void CheckReceivedSubscriptions(String s) {

        InteractionRoot interaction = null;
        ObjectReflector reflector = null;

            while ((interaction = getNextInteractionNoWait()) != null) {
                if (interaction instanceof SimTime) {
                    handleInteractionClass((SimTime) interaction);
                }
                else if (interaction instanceof ResourcePhysicalState) {
                    handleInteractionClass((ResourcePhysicalState) interaction);
                }
                else if (interaction instanceof TMYWeather) {
                    handleInteractionClass((TMYWeather) interaction);
                }
                        log.info("Interaction received and handled: " + s);
            }
 
        }
    
    private void execute() throws Exception {
        double logicalTime = 0;
        
        /////////////////////////////////////////////
        // TODO perform basic initialization below 
        /////////////////////////////////////////////

        AdvanceTimeRequest atr = new AdvanceTimeRequest(logicalTime);
        putAdvanceTimeRequest(atr);

        readyToPopulate();

        ///////////////////////////////////////////////////////////////////////
        // Call CheckReceivedSubscriptions(<message>) here to receive 
        // subscriptions published before the first time step.
        ///////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////
        // TODO perform initialization that depends on other federates below
        ///////////////////////////////////////////////////////////////////////
        readyToRun();

        startAdvanceTimeThread();
    
        while (true) {
            //////////////////////////////////////////////////////////////
            // TODO update step size for logical time progression below
            //////////////////////////////////////////////////////////////
            logicalTime += 1.0;

            atr.requestSyncStart();
            ////////////////////////////////////////////////////////////////////////////////////////
            // TODO send interactions that must be sent every logical time step below.
            // Set the interaction's parameters.
            //
            //    Quote vQuote = create_Quote(); 
            //    vQuote.set_tenderComponent_PriceCurve_price( < YOUR VALUE HERE > );
            //    vQuote.sendInteraction(getRTI(), logicalTime);
            //
            ////////////////////////////////////////////////////////////////////////////////////////


           CheckReceivedSubscriptions("Main Loop");

            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            // DO NOT MODIFY FILE BEYOND THIS LINE
            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            AdvanceTimeRequest newATR = new AdvanceTimeRequest(logicalTime);
            putAdvanceTimeRequest(newATR);
            atr.requestSyncEnd();
            atr = newATR;
        }
    }
        
    
    private void handleInteractionClass(SimTime interaction) {
        //////////////////////////////////////////////////////////////////////////
        // TODO implement how to handle reception of the interaction            
        //////////////////////////////////////////////////////////////////////////
    } 
    
    private void handleInteractionClass(ResourcePhysicalState interaction) {
        //////////////////////////////////////////////////////////////////////////
        // TODO implement how to handle reception of the interaction            
        //////////////////////////////////////////////////////////////////////////
    } 
    
    private void handleInteractionClass(TMYWeather interaction) {
        //////////////////////////////////////////////////////////////////////////
        // TODO implement how to handle reception of the interaction            
        //////////////////////////////////////////////////////////////////////////
    } 

    

    public static void main(String[] args) {
        try {
            // Comment from MB.
            Utility instance = new Utility(args);
            instance.execute();
        } catch (Exception e) {
            System.err.println("Exception caught: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

