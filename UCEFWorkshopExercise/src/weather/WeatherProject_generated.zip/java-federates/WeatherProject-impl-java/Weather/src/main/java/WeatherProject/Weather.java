package WeatherProject;

import c2w.hla.InteractionRoot;
import c2w.hla.ObjectRoot;
import c2w.hla.base.ObjectReflector;

import c2w.hla.base.AdvanceTimeRequest;

import hla.rti.SuppliedAttributes;
import hla.rti.jlc.RtiFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/**
 * The federate federate for the federation federation designed in WebGME.
 *
 * This federate MUST join the federation before the federation manager starts the experiment.
 * This means that, when the federate joins, the federation logical time must be 0 and both
 * the readyToPopulate and the readyToRun synchronization points must be defined.
 */
public class Weather extends WeatherBase {

    private final static Logger log = LogManager.getLogger(Weather.class);

   ///////////////////////////////////////////////////////////////////////
   // TODO Instatiate objects. that must be sent every logical time step 
   //
   //
   ///////////////////////////////////////////////////////////////////////

    public Weather(String[] args) throws Exception {
        super(args);
        ///////////////////////////////////////////////////////////////////////
        // TODO Must register object instances after super(args)
        //
        //
        ///////////////////////////////////////////////////////////////////////
}

    private void CheckReceivedSubscriptions(String s) {

        InteractionRoot interaction = null;
        ObjectReflector reflector = null;

            while ((interaction = getNextInteractionNoWait()) != null) {
                if (interaction instanceof SimTime) {
                    handleInteractionClass((SimTime) interaction);
                }
                        log.info("Interaction received and handled: " + s);
            }
 
        }
    
    private void execute() throws Exception {
        double logicalTime = 0;
        
        /////////////////////////////////////////////
        // TODO perform basic initialization below 
        /////////////////////////////////////////////

        AdvanceTimeRequest atr = new AdvanceTimeRequest(logicalTime);
        putAdvanceTimeRequest(atr);

        readyToPopulate();

        ///////////////////////////////////////////////////////////////////////
        // Call CheckReceivedSubscriptions(<message>) here to receive 
        // subscriptions published before the first time step.
        ///////////////////////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////////////////////
        // TODO perform initialization that depends on other federates below
        ///////////////////////////////////////////////////////////////////////
        readyToRun();

        startAdvanceTimeThread();
    
        while (true) {
            //////////////////////////////////////////////////////////////
            // TODO update step size for logical time progression below
            //////////////////////////////////////////////////////////////
            logicalTime += 1.0;

            atr.requestSyncStart();
            ////////////////////////////////////////////////////////////////////////////////////////
            // TODO send interactions that must be sent every logical time step below.
            // Set the interaction's parameters.
            //
            //    TMYWeather vTMYWeather = create_TMYWeather(); 
            //    vTMYWeather.set_aerosolOpticalDepth( < YOUR VALUE HERE > );
            //    vTMYWeather.set_aerosolOpticalDepthSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_aerosolOpticalDepthUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_albedo( < YOUR VALUE HERE > );
            //    vTMYWeather.set_albedoSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_albedoUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_ceilingHeight( < YOUR VALUE HERE > );
            //    vTMYWeather.set_ceilingHeightSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_ceilingHeightUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_date( < YOUR VALUE HERE > );
            //    vTMYWeather.set_dewPointTemperature( < YOUR VALUE HERE > );
            //    vTMYWeather.set_dewPointTemperatureSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_dewPointTemperatureUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_diffuseHorizontalIlluminance( < YOUR VALUE HERE > );
            //    vTMYWeather.set_diffuseHorizontalIlluminanceSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_diffuseHorizontalIlluminanceUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_diffuseHorizontalIrradiancSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_diffuseHorizontalIrradiancUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_diffuseHorizontalIrradiance( < YOUR VALUE HERE > );
            //    vTMYWeather.set_directNormalIlluminance( < YOUR VALUE HERE > );
            //    vTMYWeather.set_directNormalIlluminanceSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_directNormalIlluminanceUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_directNormalIrradiance( < YOUR VALUE HERE > );
            //    vTMYWeather.set_directNormalIrradianceSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_directNormalIrradianceUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_dryBulbTemperature( < YOUR VALUE HERE > );
            //    vTMYWeather.set_dryBulbTemperatureSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_dryBulbTemperatureUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_elevation( < YOUR VALUE HERE > );
            //    vTMYWeather.set_extraTerrestrialRadiation( < YOUR VALUE HERE > );
            //    vTMYWeather.set_extraTerrestrialRadiationNormal( < YOUR VALUE HERE > );
            //    vTMYWeather.set_globalHorizontalIlluminance( < YOUR VALUE HERE > );
            //    vTMYWeather.set_globalHorizontalIlluminanceSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_globalHorizontalIlluminanceUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_globalHorizontalIrradiance( < YOUR VALUE HERE > );
            //    vTMYWeather.set_globalHorizontalIrradianceSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_globalHorizontalIrradianceUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_horizontalVisibility( < YOUR VALUE HERE > );
            //    vTMYWeather.set_horizontalVisibilitySource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_horizontalVisibilityUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_latitude( < YOUR VALUE HERE > );
            //    vTMYWeather.set_liquidPrecipitationDepth( < YOUR VALUE HERE > );
            //    vTMYWeather.set_liquidPrecipitationDepthSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_liquidPrecipitationDepthUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_liquidPrecipitationQuantity( < YOUR VALUE HERE > );
            //    vTMYWeather.set_longitude( < YOUR VALUE HERE > );
            //    vTMYWeather.set_opaqueSkyCover( < YOUR VALUE HERE > );
            //    vTMYWeather.set_opaqueSkyCoverSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_opaqueSkyCoverUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_precipitableWater( < YOUR VALUE HERE > );
            //    vTMYWeather.set_precipitableWaterSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_precipitableWaterUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_presentWeather( < YOUR VALUE HERE > );
            //    vTMYWeather.set_presentWeatherSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_presentWeatherUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_pressure( < YOUR VALUE HERE > );
            //    vTMYWeather.set_pressureSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_pressureUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_relativeHumidity( < YOUR VALUE HERE > );
            //    vTMYWeather.set_relativeHumiditySource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_relativeHumidityUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_stationIDCode( < YOUR VALUE HERE > );
            //    vTMYWeather.set_stationName( < YOUR VALUE HERE > );
            //    vTMYWeather.set_stationState( < YOUR VALUE HERE > );
            //    vTMYWeather.set_time( < YOUR VALUE HERE > );
            //    vTMYWeather.set_timeZone( < YOUR VALUE HERE > );
            //    vTMYWeather.set_totalSkyCover( < YOUR VALUE HERE > );
            //    vTMYWeather.set_totalSkyCoverSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_totalSkyCoverUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_windDirection( < YOUR VALUE HERE > );
            //    vTMYWeather.set_windDirectionSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_windDirectionUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_windSpeed( < YOUR VALUE HERE > );
            //    vTMYWeather.set_windSpeedSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_windSpeedUncertainty( < YOUR VALUE HERE > );
            //    vTMYWeather.set_zenithLuminance( < YOUR VALUE HERE > );
            //    vTMYWeather.set_zenithLuminanceSource( < YOUR VALUE HERE > );
            //    vTMYWeather.set_zenithLuminanceUncertianty( < YOUR VALUE HERE > );
            //    vTMYWeather.sendInteraction(getRTI(), logicalTime);
            //
            ////////////////////////////////////////////////////////////////////////////////////////


           CheckReceivedSubscriptions("Main Loop");

            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            // DO NOT MODIFY FILE BEYOND THIS LINE
            // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            AdvanceTimeRequest newATR = new AdvanceTimeRequest(logicalTime);
            putAdvanceTimeRequest(newATR);
            atr.requestSyncEnd();
            atr = newATR;
        }
    }
        
    
    private void handleInteractionClass(SimTime interaction) {
        //////////////////////////////////////////////////////////////////////////
        // TODO implement how to handle reception of the interaction            
        //////////////////////////////////////////////////////////////////////////
    } 

    

    public static void main(String[] args) {
        try {
            // Comment from MB.
            Weather instance = new Weather(args);
            instance.execute();
        } catch (Exception e) {
            System.err.println("Exception caught: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

